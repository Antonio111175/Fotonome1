VERSIONE 2 - FOTO NOME + WHATSAPP

La app dichiara Android di essere una destinazione per immagini condivise.
Da WhatsApp:
1. Apri una foto.
2. Premi Condividi.
3. Seleziona Foto Nome.
4. La foto viene copiata nella memoria privata dell'app.
5. Inserisci un nome e premi SALVA.

La copia rimane nell'app anche se l'originale viene eliminato dalla galleria.

Per creare l'APK aprire la cartella in Android Studio e usare Build > Build APK(s).
