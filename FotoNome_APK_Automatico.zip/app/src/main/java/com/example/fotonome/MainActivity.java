package com.example.fotonome;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout list;
    private SharedPreferences prefs;
    private ArrayList<Uri> incoming = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("photos",MODE_PRIVATE);
        buildMain();
        handleIncoming(getIntent());
    }

    private void buildMain(){
        LinearLayout main=new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(25,22,25,22);

        TextView title=new TextView(this);
        title.setText("📷  LE MIE FOTO");
        title.setTextSize(26); title.setGravity(Gravity.CENTER);
        main.addView(title,new LinearLayout.LayoutParams(-1,-2));

        Button add=new Button(this);
        add.setText("＋  AGGIUNGI FOTO DALLA GALLERIA");
        add.setOnClickListener(v->pick());
        main.addView(add);

        TextView hint=new TextView(this);
        hint.setText("Puoi anche usare WhatsApp → Condividi → Foto Nome");
        hint.setGravity(Gravity.CENTER); hint.setTextColor(Color.DKGRAY);
        main.addView(hint,new LinearLayout.LayoutParams(-1,-2));

        ScrollView s=new ScrollView(this);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        s.addView(list); main.addView(s,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(main); refresh();
    }

    private void pick(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,10);
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==10&&c==RESULT_OK&&d!=null&&d.getData()!=null) receive(d.getData());
    }

    private void handleIncoming(Intent i){
        if(i==null)return;
        String a=i.getAction();
        if(Intent.ACTION_SEND.equals(a)){
            Uri u=i.getParcelableExtra(Intent.EXTRA_STREAM);
            if(u!=null) receive(u);
        } else if(Intent.ACTION_SEND_MULTIPLE.equals(a)){
            ArrayList<Uri> us=i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if(us!=null&&!us.isEmpty()){
                // Per la prova, salviamo la prima foto ricevuta.
                receive(us.get(0));
                if(us.size()>1) Toast.makeText(this,"Per la prova è stata ricevuta la prima foto.",Toast.LENGTH_LONG).show();
            }
        }
    }

    private void receive(Uri u){
        try{
            final Uri copy=copyIntoApp(u);
            EditText e=new EditText(this); e.setSingleLine(true); e.setHint("Es. Carro 2026");
            new AlertDialog.Builder(this).setTitle("Foto ricevuta")
                .setMessage("La foto è stata copiata nell'app. Inserisci il nome.")
                .setView(e).setNegativeButton("ANNULLA",null)
                .setPositiveButton("SALVA",(x,w)->{
                    String n=e.getText().toString().trim();
                    if(n.isEmpty()) n="Foto "+(prefs.getAll().size()+1);
                    String key="p_"+System.currentTimeMillis();
                    prefs.edit().putString(key,n+"||"+copy.toString()).apply();
                    refresh();
                }).show();
        }catch(Exception ex){
            Toast.makeText(this,"Non riesco a copiare la foto: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private Uri copyIntoApp(Uri source) throws Exception{
        File dir=new File(getFilesDir(),"photos"); if(!dir.exists())dir.mkdirs();
        File out=new File(dir,"img_"+System.currentTimeMillis()+".jpg");
        InputStream in=getContentResolver().openInputStream(source);
        FileOutputStream fos=new FileOutputStream(out);
        byte[] buf=new byte[8192]; int n;
        while((n=in.read(buf))!=-1)fos.write(buf,0,n);
        in.close(); fos.close();
        return Uri.fromFile(out);
    }

    private void refresh(){
        list.removeAllViews();
        Map<String,?> all=prefs.getAll();
        if(all.isEmpty()){
            TextView e=new TextView(this);
            e.setText("Nessuna foto.\n\nDa WhatsApp: Foto → Condividi → Foto Nome");
            e.setTextSize(17);e.setGravity(Gravity.CENTER);e.setTextColor(Color.GRAY);
            e.setPadding(10,60,10,60);list.addView(e);return;
        }
        ArrayList<String> ks=new ArrayList<>(all.keySet()); Collections.sort(ks,Collections.reverseOrder());
        for(String k:ks){
            String[] p=String.valueOf(all.get(k)).split("\\|\\|",2); if(p.length<2)continue;
            Button b=new Button(this);b.setText("📷  "+p[0]);b.setTextSize(18);b.setAllCaps(false);
            b.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
            b.setOnClickListener(v->open(Uri.parse(p[1]),p[0]));
            b.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("Elimina")
                .setMessage("Eliminare "+p[0]+"?").setNegativeButton("NO",null)
                .setPositiveButton("SÌ",(d,w)->{prefs.edit().remove(k).apply();refresh();}).show();return true;});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,70);lp.setMargins(0,0,0,8);
            list.addView(b,lp);
        }
    }

    private void open(Uri u,String name){
        ImageView im=new ImageView(this); im.setAdjustViewBounds(true); im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        im.setImageURI(u);
        new AlertDialog.Builder(this).setTitle(name).setView(im).setPositiveButton("CHIUDI",null).show();
    }

    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleIncoming(i);}
}
